import kotlin.Exception        

fun calculateBrakingDistance(v1: String, a: String): Int {
    // write your code here
}