package cinema

fun main() {
    println("Enter the number of rows:")
    print("> ")
    val rows = readLine()!!.toInt()
    println("Enter the number of seats in each row:")
    print("> ")
    val seatsInRow = readLine()!!.toInt()
    val totalSeats = rows * seatsInRow
    val cinema = cinemaEdges(rows, seatsInRow)
    var soldTicketsTen = 0
    var soldTicketsEight = 0
    val totalIncome = if (totalSeats <= 60) {
        totalSeats * 10
    } else {
        val frontSeats = rows / 2 * seatsInRow
        val backSeats = totalSeats - frontSeats
        frontSeats * 10 + backSeats * 8
    }

    loop1@ while (true) {
    println("1. Show the seats")
    println("2. Buy a ticket")
    println("3. Statistics")
    println("0. Exit")
    print(">")
    when(readLine()!!.toInt()) {
        1 -> cinemaPrinter(cinema, rows)
        2 -> loop2@ while (true){
            println("Enter a row number:")
            print("> ")
            val x = readLine()!!.toInt()
            println("Enter a seat number in that row:")
            print("> ")
            val y = readLine()!!.toInt()
            when {
                x > rows || y > seatsInRow -> {
                    println("Wrong input!")
                    continue@loop1
                }
                cinema[x][y] == "B" -> {
                    println("That ticket has already been purchased")
                    println("enter different seat coordinates")
                    continue@loop2
                }
                cinema[x][y] == "S" -> cinema[x][y] = "B"
            }
            var ticketPrice = 10
            if (totalSeats <= 60) {
                ticketPrice = 10
                soldTicketsTen++
            } else {
                if (x <= rows / 2) {
                    ticketPrice = 10
                    soldTicketsTen++
                } else if (x > rows/2) {
                    ticketPrice = 8
                    soldTicketsEight++
                }
            }
            println("Ticket price: \$$ticketPrice")
            continue@loop1
        }
        3 -> {
            val soldTickets = soldTicketsTen + soldTicketsEight
            val percentage = String.format("%.2f", soldTickets.toDouble() * 100 / totalSeats.toDouble())
            val income = soldTicketsTen * 10 + soldTicketsEight * 8
            println("Number of purchased tickets: $soldTickets")
            println("Percentage: $percentage%")
            println("Current income: \$$income")
            println("Total income: \$$totalIncome")
        }
        0 -> break
    }
    }
}
fun cinemaEdges(rows: Int, seatsInRow: Int): MutableList<MutableList<String>> {
    val cinema = MutableList(rows + 1){ MutableList(seatsInRow + 1) {"S"} }
    cinema[0][0] = " "
    //change first row for numbers from 1 to the given limit
    for (i in 1..seatsInRow) {
        cinema[0][i] = i.toString()
    }
    //change first column for numbers from 1 the given limit
    for (i in 1..rows) {
        cinema[i][0] = i.toString()
    }
    return cinema
}
fun cinemaPrinter (cinema: MutableList<MutableList<String>>, rows: Int) {
    println("Cinema:")
    for (i in 0..rows) {
        println(cinema[i].joinToString(" "))
    }
}

